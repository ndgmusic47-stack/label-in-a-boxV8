"""
Mix service for audio processing and mixing
"""
import logging
import asyncio
from pathlib import Path
from pydub import AudioSegment
from pydub.effects import normalize
from pydub.exceptions import CouldntDecodeError

from backend.dsp.dsp_chain import process_vocal
from backend.mix_service import apply_basic_mix
from backend.orchestrator import ProjectOrchestrator
from backend.utils.responses import error_response, success_response

logger = logging.getLogger(__name__)

MAX_DURATION_MS = 10 * 60 * 1000  # 10 minutes


class MixService:
    """Service for handling audio mixing operations"""
    
    @staticmethod
    async def run_clean_mix(request, user_id: str) -> dict:
        """
        Clean mix with DSP processing: overlay processed vocal on beat
        
        Args:
            request: CleanMixRequest object with vocal_url, beat_url, session_id, etc.
            user_id: User ID for orchestrator updates
            
        Returns:
            Success or error response dict
        """
        logger.info("Running clean mix…")
        
        try:
            # Resolve file paths (handle both /media/... and ./media/... paths)
            vocal_path = request.vocal_url
            if vocal_path.startswith("/media/"):
                vocal_path = "." + vocal_path
            elif not vocal_path.startswith("./"):
                vocal_path = "./" + vocal_path.lstrip("/")
            
            beat_path = request.beat_url
            if beat_path.startswith("/media/"):
                beat_path = "." + beat_path
            elif not beat_path.startswith("./"):
                beat_path = "./" + beat_path.lstrip("/")
            
            # ========================================================================
            # 1. AUDIO VALIDATION (before DSP)
            # ========================================================================
            
            # Validate vocal file (async file checks)
            vocal_path_obj = Path(vocal_path)
            vocal_exists = await asyncio.to_thread(vocal_path_obj.exists)
            if not vocal_exists:
                return error_response(
                    "INVALID_AUDIO",
                    400,
                    "The provided vocal or beat file is corrupted or unsupported."
                )
            
            vocal_is_file = await asyncio.to_thread(vocal_path_obj.is_file)
            if not vocal_is_file:
                return error_response(
                    "INVALID_AUDIO",
                    400,
                    "The provided vocal or beat file is corrupted or unsupported."
                )
            
            vocal_stat = await asyncio.to_thread(vocal_path_obj.stat)
            if vocal_stat.st_size == 0:
                return error_response(
                    "INVALID_AUDIO",
                    400,
                    "The provided vocal or beat file is corrupted or unsupported."
                )
            
            # Validate beat file (async file checks)
            beat_path_obj = Path(beat_path)
            beat_exists = await asyncio.to_thread(beat_path_obj.exists)
            if not beat_exists:
                return error_response(
                    "INVALID_AUDIO",
                    400,
                    "The provided vocal or beat file is corrupted or unsupported."
                )
            
            beat_is_file = await asyncio.to_thread(beat_path_obj.is_file)
            if not beat_is_file:
                return error_response(
                    "INVALID_AUDIO",
                    400,
                    "The provided vocal or beat file is corrupted or unsupported."
                )
            
            beat_stat = await asyncio.to_thread(beat_path_obj.stat)
            if beat_stat.st_size == 0:
                return error_response(
                    "INVALID_AUDIO",
                    400,
                    "The provided vocal or beat file is corrupted or unsupported."
                )
            
            # Check file format (WAV/MP3)
            vocal_ext = vocal_path_obj.suffix.lower()
            beat_ext = beat_path_obj.suffix.lower()
            
            if vocal_ext not in ['.wav', '.mp3']:
                return error_response(
                    "INVALID_AUDIO",
                    400,
                    "The provided vocal or beat file is corrupted or unsupported."
                )
            
            if beat_ext not in ['.wav', '.mp3']:
                return error_response(
                    "INVALID_AUDIO",
                    400,
                    "The provided vocal or beat file is corrupted or unsupported."
                )
            
            # ==========================
            # PHASE 4: SAFETY VALIDATION
            # ==========================

            try:
                # Run blocking AudioSegment operations in thread pool
                vocal = await asyncio.to_thread(AudioSegment.from_file, vocal_path)
                beat = await asyncio.to_thread(AudioSegment.from_file, beat_path)
            except CouldntDecodeError:
                return error_response("INVALID_AUDIO", 400, "Could not decode audio")

            # Length checks
            if len(vocal) <= 0 or len(beat) <= 0:
                return error_response("INVALID_AUDIO", 400, "Empty audio file")
            if len(vocal) > MAX_DURATION_MS or len(beat) > MAX_DURATION_MS:
                return error_response("FILE_TOO_LONG", 400, "Audio file exceeds maximum duration")

            # Sample rate/channel matching
            if vocal.frame_rate != beat.frame_rate:
                vocal = vocal.set_frame_rate(beat.frame_rate)
            if vocal.channels != beat.channels:
                if beat.channels == 2:
                    vocal = vocal.set_channels(2)
                else:
                    vocal = vocal.set_channels(1)

            # Loudness guard
            max_dBFS = vocal.max_dBFS
            if max_dBFS < -60:
                return error_response("INVALID_AUDIO", 400, "Vocal is too quiet")
            if max_dBFS > 0:
                vocal -= 3

            # ==========================
            # DSP PROCESSING
            # ==========================
            try:
                processed_vocal = process_vocal(vocal)
            except Exception as e:
                logger.error(f"DSP error: {e}")
                return error_response("DSP_FAILURE", 500, f"DSP processing failed: {str(e)}")

            # Save processed vocal separately
            processed_dir = Path(f"./media/{user_id}/{request.session_id}/mix/")
            processed_vocal_url = f"/media/{user_id}/{request.session_id}/mix/processed_vocal.wav"
            processed_dir.mkdir(parents=True, exist_ok=True)
            processed_vocal_path = processed_dir / "processed_vocal.wav"
            await asyncio.to_thread(processed_vocal.export, processed_vocal_path, format="wav")

            # ==========================
            # MIXING
            # ==========================
            min_len = min(len(beat), len(processed_vocal))
            beat = beat[:min_len]
            processed_vocal = processed_vocal[:min_len]
            mixed = beat.overlay(processed_vocal - 2)

            mixed = normalize(mixed)
            mixed -= 1.5

            # ==========================
            # EXPORT FINAL MIX
            # ==========================
            mix_dir = Path(f"./media/{user_id}/{request.session_id}/mix/")
            mix_url = f"/media/{user_id}/{request.session_id}/mix/mix_clean.wav"
            mix_dir.mkdir(parents=True, exist_ok=True)
            output_path = mix_dir / "mix_clean.wav"
            await asyncio.to_thread(mixed.export, output_path, format="wav")

            # ==========================
            # LOGGING + METADATA
            # ==========================
            logger.info(f"Processed vocal peak: {processed_vocal.max_dBFS}")
            logger.info(f"Mixed peak: {mixed.max_dBFS}")

            # Phase 6: Auto-save to orchestrator
            orchestrator = ProjectOrchestrator(user_id, request.session_id)
            orchestrator.update_stage("mix", {
                "mix_url": mix_url,
                "processed_vocal_url": processed_vocal_url,
                "duration_ms": len(mixed),
                "peak_dB": mixed.max_dBFS,
                "completed": True
            })

            return success_response(
                data={
                    "mix_url": mix_url,
                    "processed_vocal_url": processed_vocal_url,
                    "duration_ms": len(mixed),
                    "peak_dB": mixed.max_dBFS,
                    "rms_dB": mixed.rms,
                },
                message="Mix generated successfully"
            )
            
        except CouldntDecodeError:
            return error_response(
                "INVALID_AUDIO",
                400,
                "Could not decode audio."
            )
        except Exception as e:
            logger.error(f"Clean mix failed: {e}")
            return error_response("UNEXPECTED_ERROR", 500, f"Failed to create clean mix: {str(e)}")
    
    @staticmethod
    async def mix_audio(user_id: str, session_id: str) -> dict:
        """
        Basic mix using apply_basic_mix function
        
        Args:
            user_id: User ID
            session_id: Session ID
            
        Returns:
            Success response dict with mix_url
        """
        # compute paths
        base = Path(f"./media/{user_id}/{session_id}")

        vocal_path = base / "vocal.wav"
        beat_path = base / "beat.mp3"
        output_path = base / "mix" / "mix.wav"

        # run DSP chain
        await asyncio.to_thread(
            apply_basic_mix,
            str(vocal_path),
            str(beat_path),
            str(output_path)
        )

        # update project.json
        result_url = f"/media/{user_id}/{session_id}/mix/mix.wav"
        orchestrator = ProjectOrchestrator(user_id, session_id)
        await orchestrator.update_stage(
            "mix",
            {
                "path": result_url,
                "processed": True
            }
        )

        return success_response(
            data={"mix_url": result_url},
            message="Mix generated successfully"
        )

