"""
Label-in-a-Box Phase 2 Backend - Production Demo
Clean backend using ONLY: Beatoven, OpenAI (text), Auphonic, GetLate, local services
"""

import os
from pathlib import Path
import logging

from fastapi import FastAPI, APIRouter
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from fastapi.staticfiles import StaticFiles

# Import routers
from content import content_router
from auth import auth_router
from routers.billing_router import billing_router
from routers.beat_router import beat_router
from routers.lyrics_router import lyrics_router
from routers.media_router import media_router
from routers.release_router import release_router
from routers.analytics_router import analytics_router
from routers.social_router import social_router
from utils.rate_limit import RateLimiterMiddleware
from database import init_db

# ============================================================================
# PHASE 2.2: SHARED UTILITIES
# ============================================================================

# Logging setup - write ALL events to /logs/app.log
LOGS_DIR = Path("./logs")
LOGS_DIR.mkdir(exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOGS_DIR / "app.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Phase 1 normalized JSON response helpers - now from unified module
from backend.utils.responses import success_response, error_response

# ============================================================================
# FASTAPI APP SETUP
# ============================================================================

app = FastAPI(title="Label in a Box v4 - Phase 2.2")

# Phase 1: Required API keys for startup validation
REQUIRED_KEYS = [
    "OPENAI_API_KEY",
    "BEATOVEN_API_KEY",
    "BUFFER_TOKEN",
    "DISTROKID_KEY",
]

# CORS middleware (Phase 1 hardening)
allowed_origins = [
    "http://localhost:5173",
    "https://labelinabox.com",
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# Rate limiting middleware (Phase 1)
app.add_middleware(RateLimiterMiddleware, requests_per_minute=30)

# Enforce HTTPS in production (Render)
def _is_render_env() -> bool:
    return bool(os.getenv("RENDER") or os.getenv("RENDER_EXTERNAL_URL") or os.getenv("RENDER_SERVICE_NAME"))

class EnforceHTTPSMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        if _is_render_env():
            proto = request.headers.get("x-forwarded-proto", "")
            if proto and proto.lower() != "https":
                return error_response("HTTPS required", status_code=403)
        return await call_next(request)

app.add_middleware(EnforceHTTPSMiddleware)

# Security headers middleware
class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Add security headers to all responses: CSP, HSTS, X-Frame-Options, X-Content-Type-Options"""
    async def dispatch(self, request, call_next):
        response = await call_next(request)
        
        # Content-Security-Policy: Strict CSP to mitigate XSS risks
        # Allow self, inline scripts/styles (for frontend), and Beatoven API
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline'; "
            "connect-src 'self' https://public-api.beatoven.ai; "
            "img-src 'self' data: blob:; "
            "font-src 'self' data:; "
            "object-src 'none'; "
            "base-uri 'self'; "
            "form-action 'self';"
        )
        
        # Strict-Transport-Security: Enforce HTTPS for 1 year, include subdomains
        # Only set in production (Render environment) where HTTPS is guaranteed
        if _is_render_env():
            response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        
        # X-Frame-Options: Prevent clickjacking attacks
        response.headers["X-Frame-Options"] = "DENY"
        
        # X-Content-Type-Options: Prevent MIME type sniffing
        response.headers["X-Content-Type-Options"] = "nosniff"
        
        return response

app.add_middleware(SecurityHeadersMiddleware)

# Directory setup
MEDIA_DIR = Path("./media")
ASSETS_DIR = Path("./assets")
FRONTEND_DIST = Path("./frontend/dist")
MEDIA_DIR.mkdir(exist_ok=True)
ASSETS_DIR.mkdir(exist_ok=True)
(ASSETS_DIR / "demo").mkdir(exist_ok=True)

# Serve static files
app.mount("/media", StaticFiles(directory=str(MEDIA_DIR)), name="media")

# ============================================================================
# API ROUTER WRAPPER (adds /api prefix for all endpoints)
# ============================================================================
# Note: The api router is kept for potential future use, but currently all
# endpoints are defined in their respective router modules
api = APIRouter(prefix="/api")

# ============================================================================
# STARTUP CHECKS - ENV KEYS (Phase 1)
# ============================================================================
@app.on_event("startup")
async def check_env_keys_on_startup():
    missing = []
    for env_key in ["OPENAI_API_KEY", "SUNO_API_KEY", "BUFFER_TOKEN", "DISTROKID_KEY"]:
        if not os.getenv(env_key):
            missing.append(env_key)
    if missing:
        logger.warning(f"Startup check: Missing environment variables: {', '.join(missing)}")
    else:
        logger.info("Startup check: All critical environment variables are set")

# Phase 1: Additional startup validation for required keys (non-fatal)
@app.on_event("startup")
async def validate_keys():
    missing = [key for key in REQUIRED_KEYS if not os.getenv(key)]
    if missing:
        logger.warning(f"⚠️ Missing API keys: {missing}")
    else:
        logger.info("🔐 All API keys loaded successfully")

# Initialize database on startup
@app.on_event("startup")
async def initialize_database():
    """Initialize the SQLite database and create all tables."""
    await init_db()
    logger.info("✅ Database initialized successfully")

# ============================================================================
# INCLUDE ROUTERS
# ============================================================================
app.include_router(auth_router)
app.include_router(content_router)
app.include_router(billing_router)
app.include_router(beat_router)
app.include_router(lyrics_router)
app.include_router(media_router)
app.include_router(release_router)
app.include_router(analytics_router)
app.include_router(social_router)

# ============================================================================
# FRONTEND SERVING (MUST BE LAST - AFTER ALL API ROUTES)
# ============================================================================

# Serve frontend in production (if built)
# IMPORTANT: Mount order matters - this must be after all API routes
if FRONTEND_DIST.exists():
    # Serve frontend assets (CSS, JS, images)
    if (FRONTEND_DIST / "assets").exists():
        app.mount("/assets", StaticFiles(directory=str(FRONTEND_DIST / "assets")), name="assets")
    
    # Serve frontend static files (HTML, CSS, JS) - catch-all route (must be last)
    app.mount("/", StaticFiles(directory=str(FRONTEND_DIST), html=True), name="frontend")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

